// /* =====================
//    GLOBAL STATE
// ===================== */
// let isLoggedIn = false;
// let currentUser = null;

// const DEFAULT_IMAGE = "images/icon.png";

// /* =====================
//    SCREEN NAVIGATION
// ===================== */
// function showScreen(screenId) {
//   if (!isLoggedIn && screenId !== "login" && screenId !== "register") {
//     alert("Please login first");
//     return;
//   }

//   document.querySelectorAll(".screen").forEach(screen => {
//     screen.classList.remove("active");
//   });

//   const screenToShow = document.getElementById(screenId);
//   if (screenToShow) {
//     screenToShow.classList.add("active");
//   } else {
//     console.error(`No screen found with id: ${screenId}`);
//   }

//   updateNavbar();
// }

// /* =====================
//    NAVBAR CONTROL
// ===================== */
// function updateNavbar() 
// {document.getElementById("navBeforeLogin").style.display =
//   isLoggedIn ? "none" : "flex";

// document.getElementById("navAfterLogin").style.display =
//   isLoggedIn ? "flex" : "none";
// }

// /* =====================
//    REGISTER
// ===================== */
// // function register() {
// //   const username = document.getElementById("regName").value.trim();
// //   const email = document.getElementById("regEmail").value.trim();
// //   const password = document.getElementById("regPassword").value.trim();

// //   if (!username || !email || !password) {
// //     alert("Please fill all fields");
// //     return;
// //   }

// //   fetch("http://localhost:8080/api/register", {
// //     method: "POST",
// //     headers: { "Content-Type": "application/json" },
// //     body: JSON.stringify({ username, email, password })
// //   })
// //     .then(res => res.json())
// //     .then(data => {
// //       if (data.error) {
// //         alert(data.error);
// //       } else {
// //         alert("Registration successful! Please login.");
// //         showScreen("login");
// //       }
// //     })
// //     .catch(err => {
// //       console.error("Registration error:", err);
// //       alert("Registration failed. Please try again.");
// //     });
// // }

// function register() {
//   const username = document.getElementById("regName").value.trim();
//   const email = document.getElementById("regEmail").value.trim();
//   const password = document.getElementById("regPassword").value.trim();

//   if (!username || !email || !password) {
//     alert("Please fill all fields");
//     return;
//   }

//   const user = { username, email, password };
//   localStorage.setItem("user", JSON.stringify(user));

//   alert("Registration successful!");
//   showScreen("login");
// }

// /* =====================
//    LOGIN (ASYNC / AWAIT)
// ===================== */
// function login() {
//   const email = document.getElementById("loginEmail").value.trim();
//   const password = document.getElementById("loginPassword").value.trim();

//   if (!email || !password) {
//     alert("Please enter email and password");
//     return;
//   }

//   const storedUser = JSON.parse(localStorage.getItem("user"));

//   if (!storedUser) {
//     alert("No user found. Please register first.");
//     return;
//   }

//   if (storedUser.email === email && storedUser.password === password) {
//     isLoggedIn = true;
//     currentUser = storedUser;

//     localStorage.setItem("isLoggedIn", "true");
//     localStorage.setItem("currentUser", JSON.stringify(storedUser));

//     document.querySelector("#dashboard h2").textContent =
//       `Welcome to SkillBridge, ${storedUser.username}!`;

//     showScreen("dashboard");
//   } else {
//     alert("Invalid email or password");
//   }
// }

// /* =====================
//    LOGOUT
// ===================== */
// function logout() {
//   isLoggedIn = false;
//   currentUser = null;

//   localStorage.removeItem("isLoggedIn");
//   localStorage.removeItem("currentUser");

//   updateNavbar();
//   showScreen("login");

//   alert("Logged out successfully!");
// }


// /* =====================
//    PROFILE IMAGE
// ===================== */
// function uploadProfileImage(event) {
//   const file = event.target.files[0];
//   if (!file || !currentUser) return;

//   const reader = new FileReader();
//   reader.onload = () => {
//     const base64Image = reader.result;

//     fetch("http://localhost:8080/api/profile-image", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({
//         email: currentUser.email,
//         image: base64Image
//       })
//     })
//       .then(res => res.json())
//       .then(updatedUser => {
//         currentUser = updatedUser;
//         localStorage.setItem("currentUser", JSON.stringify(updatedUser));

//         document.getElementById("profileImage").src =
//           updatedUser.profileImageBase64 || DEFAULT_IMAGE;

//         alert("Profile image updated!");
//       })
//       .catch(err => {
//         console.error("Profile image upload failed:", err);
//         alert("Failed to upload image.");
//       });
//   };

//   reader.readAsDataURL(file);
// }

// /* =====================
//    LOAD PROFILE IMAGE
// ===================== */
// function loadProfileImage() {
//   if (!currentUser) return;

//   const img = document.getElementById("profileImage");
//   img.src = currentUser.profileImageBase64 || DEFAULT_IMAGE;
// }

// /* =====================
//    AUTO LOGIN ON PAGE LOAD
// ===================== */
// window.onload = () => {
//   const savedLogin = localStorage.getItem("isLoggedIn");
//   const savedUser = localStorage.getItem("currentUser");

//   if (savedLogin === "true" && savedUser) {
//     isLoggedIn = true;
//     currentUser = JSON.parse(savedUser);
//     showScreen("dashboard");
//     loadProfileImage();
//   } else {
//     showScreen("login");
//   }
// };

// ================= GLOBAL =================
let isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
let currentUser = JSON.parse(localStorage.getItem("currentUser")) || null;

// ================= SCREEN SWITCH =================
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(screen => {
    screen.classList.remove("active");
  });
  document.getElementById(id).classList.add("active");
}

// ================= NAVBAR =================
function updateNavbar() {
  document.getElementById("navBeforeLogin").style.display =
    isLoggedIn ? "none" : "flex";

  document.getElementById("navAfterLogin").style.display =
    isLoggedIn ? "flex" : "none";
}

updateNavbar();

// ================= REGISTER =================
function register() {
  const name = document.getElementById("regName").value;
  const email = document.getElementById("regEmail").value;
  const password = document.getElementById("regPassword").value;

  if (!name || !email || !password) {
    alert("Please fill all fields");
    return;
  }

  let users = JSON.parse(localStorage.getItem("users")) || [];

  users.push({ name, email, password, skills: [], projects: [] });

  localStorage.setItem("users", JSON.stringify(users));

  alert("Registration Successful!");
  showScreen("login");
}

// ================= LOGIN =================
function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  let users = JSON.parse(localStorage.getItem("users")) || [];

  let user = users.find(u => u.email === email && u.password === password);

  if (!user) {
    alert("Invalid Email or Password");
    return;
  }

  isLoggedIn = true;
  currentUser = user;

  localStorage.setItem("isLoggedIn", "true");
  localStorage.setItem("currentUser", JSON.stringify(user));

  updateNavbar();
  showScreen("dashboard");
  loadDashboard();
  loadAdmin();
}

// ================= LOGOUT =================
function logout() {
  isLoggedIn = false;
  currentUser = null;

  localStorage.removeItem("isLoggedIn");
  localStorage.removeItem("currentUser");

  updateNavbar();
  showScreen("login");
}

// ================= DASHBOARD =================
function loadDashboard() {
  if (!currentUser) return;

  document.querySelector("#dashboard h2").innerText =
    "Welcome to SkillBridge, " + currentUser.name + "!";

  const skillsBox = document.querySelector("#dashboard .box");
  const projectsBox = document.querySelectorAll("#dashboard .box")[1];

  skillsBox.innerHTML = `
    <h3>My Skills</h3>
    <input type="text" id="newSkill" placeholder="Add Skill">
    <button onclick="addSkill()">Add</button>
  `;

  currentUser.skills.forEach(skill => {
    skillsBox.innerHTML += `<div class="skill"><b>${skill}</b></div>`;
  });

  projectsBox.innerHTML = `
    <h3>My Projects</h3>
    <input type="text" id="newProject" placeholder="Add Project">
    <button onclick="addProject()">Add</button>
  `;

  currentUser.projects.forEach(project => {
    projectsBox.innerHTML += `<div class="project">${project}</div>`;
  });
}

function addSkill() {
  const skill = document.getElementById("newSkill").value;
  if (!skill) return;

  currentUser.skills.push(skill);
  updateUserStorage();
  loadDashboard();
  loadAdmin();
}

function addProject() {
  const project = document.getElementById("newProject").value;
  if (!project) return;

  currentUser.projects.push(project);
  updateUserStorage();
  loadDashboard();
}

// ================= PROFILE IMAGE =================
function uploadProfileImage(event) {
  const reader = new FileReader();
  reader.onload = function () {
    document.getElementById("profileImage").src = reader.result;
    localStorage.setItem("profileImage", reader.result);
  };
  reader.readAsDataURL(event.target.files[0]);
}

window.onload = function () {
  const img = localStorage.getItem("profileImage");
  if (img) {
    document.getElementById("profileImage").src = img;
  }
};

// ================= CHAT =================
document.querySelector("#chat button").addEventListener("click", function () {
  const input = document.querySelector("#chat input");
  const message = input.value;

  if (!message) return;

  const chatArea = document.querySelector(".chat-area");

  const msgDiv = document.createElement("div");
  msgDiv.className = "message right";
  msgDiv.innerText = message;

  chatArea.insertBefore(msgDiv, input);
  input.value = "";
});

// ================= ADMIN =================
function loadAdmin() {
  let users = JSON.parse(localStorage.getItem("users")) || [];

  document.querySelectorAll(".big")[0].innerText = users.length;

  let totalSkills = 0;
  users.forEach(u => totalSkills += u.skills.length);

  document.querySelectorAll(".big")[1].innerText = totalSkills;

  const userList = document.querySelector(".users");
  userList.innerHTML = "";

  users.forEach(u => {
    userList.innerHTML += `<li>${u.name}</li>`;
  });
}

// ================= UPDATE STORAGE =================
function updateUserStorage() {
  let users = JSON.parse(localStorage.getItem("users")) || [];

  users = users.map(u =>
    u.email === currentUser.email ? currentUser : u
  );

  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("currentUser", JSON.stringify(currentUser));
}

