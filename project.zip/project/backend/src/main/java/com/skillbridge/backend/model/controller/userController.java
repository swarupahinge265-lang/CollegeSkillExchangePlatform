// package com.skillbridge.backend.controller;

// import com.skillbridge.backend.model.User;
// import com.skillbridge.backend.service.UserService;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;

// import java.util.Map;
// import java.util.Optional;

// @CrossOrigin(origins = "*")
// @RestController
// @RequestMapping("/api")
// public class UserController {

//  // Allow frontend access
// public class UserController {

//     private final UserService userService;

//     public UserController(UserService userService) {
//         this.userService = userService;
//     }

//     // Register endpoint
//     @PostMapping("/register")
//     public ResponseEntity<?> register(@RequestBody User user) {
//         try {
//             User savedUser = userService.registerUser(user);
//             return ResponseEntity.ok(Map.of("message", "User registered", "user", savedUser));
//         } catch (Exception e) {
//             return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
//         }
//     }

//     // Login endpoint
//     @PostMapping("/login")
//     public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {
//         String email = credentials.get("email");
//         String password = credentials.get("password");

//         Optional<User> user = userService.loginUser(email, password);
//         if (user.isPresent()) {
//             return ResponseEntity.ok(user.get());
//         } else {
//             return ResponseEntity.status(401).body(Map.of("error", "Invalid email or password"));
//         }
//     }

//     // Upload profile image
//     @PostMapping("/profile-image")
//     public ResponseEntity<?> uploadProfileImage(@RequestBody Map<String, String> body) {
//         try {
//             String email = body.get("email");
//             String image = body.get("image");
//             User updatedUser = userService.updateProfileImage(email, image);
//             return ResponseEntity.ok(updatedUser);
//         } catch (Exception e) {
//             return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
//         }
//     }
// }

package com.skillbridge.backend.controller;

import com.skillbridge.backend.model.User;
import com.skillbridge.backend.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Register endpoint
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        try {
            User savedUser = userService.registerUser(user);
            return ResponseEntity.ok(Map.of(
                    "message", "User registered successfully",
                    "user", savedUser
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                    Map.of("error", e.getMessage())
            );
        }
    }

    // Login endpoint
    // @PostMapping("/login")
    // public ResponseEntity<?> login(@RequestBody Map<String, String> credentials)
    @PostMapping("/login")
public ResponseEntity<?> login(@RequestBody Map<String, String> credentials) {

    String email = credentials.get("email");
    String password = credentials.get("password");

    Optional<User> user = userService.loginUser(email, password);

    if (user.isPresent()) {
        return ResponseEntity.ok(user.get());
    } else {
        return ResponseEntity.status(401).body(
                Map.of("error", "Invalid email or password")
        );
    }
}


    // Upload profile image
    @PostMapping("/profile-image")
    public ResponseEntity<?> uploadProfileImage(@RequestBody Map<String, String> body) {
        try {
            String email = body.get("email");
            String image = body.get("image");

            User updatedUser = userService.updateProfileImage(email, image);

            return ResponseEntity.ok(updatedUser);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                    Map.of("error", e.getMessage())
            );
        }
    }
}
